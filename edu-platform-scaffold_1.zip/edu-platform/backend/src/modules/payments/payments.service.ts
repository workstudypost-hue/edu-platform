import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentGatewayFactory } from './adapters/payment-gateway.factory';
import { GatewayProvider, PaymentPlanRelatedType } from '@prisma/client';

const REFUND_WINDOW_DAYS = 14;

@Injectable()
export class PaymentsService {
  constructor(
    private prisma: PrismaService,
    private gatewayFactory: PaymentGatewayFactory,
  ) {}

  /** ينشئ جلسة دفع عبر البوابة المختارة (بطاقة كاملة، أو قسط، حسب السياق) */
  async initiatePayment(params: {
    studentId: string;
    amountUsd: number;
    currency: string;
    provider: GatewayProvider;
    relatedType: PaymentPlanRelatedType;
    relatedId: string;
    installmentId?: string;
  }) {
    const gateway = await this.prisma.paymentGateway.findUnique({
      where: { provider: params.provider },
    });
    if (!gateway || !gateway.isActive) {
      throw new BadRequestException('بوابة الدفع المطلوبة غير متاحة حاليًا');
    }

    const adapter = this.gatewayFactory.getAdapter(params.provider);
    const session = await adapter.createPaymentIntent({
      amountUsd: params.amountUsd,
      currency: params.currency,
      studentId: params.studentId,
      metadata: {
        relatedType: params.relatedType,
        relatedId: params.relatedId,
        installmentId: params.installmentId ?? '',
      },
    });

    await this.prisma.payment.create({
      data: {
        studentId: params.studentId,
        relatedType: params.relatedType,
        relatedId: params.relatedId,
        installmentId: params.installmentId,
        amountUsd: params.amountUsd,
        currency: params.currency,
        gatewayId: gateway.id,
        gatewayTransactionId: session.sessionId,
        status: 'pending',
      },
    });

    return session;
  }

  /**
   * يُستدعى من Webhook Controller عند تأكيد نجاح الدفع من البوابة.
   * هذه هي النقطة الوحيدة التي تُعتبر فيها الدفعة "ناجحة فعليًا" -
   * ليس عند استجابة الـ API الأولية، بل عند تأكيد الـ Webhook.
   */
  async confirmPaymentSuccess(gatewayTransactionId: string, provider: GatewayProvider) {
    const adapter = this.gatewayFactory.getAdapter(provider);
    const result = await adapter.capturePayment(gatewayTransactionId);

    const payment = await this.prisma.payment.findFirst({
      where: { gatewayTransactionId },
    });
    if (!payment) return;

    await this.prisma.payment.update({
      where: { id: payment.id },
      data: {
        status: result.success ? 'completed' : 'failed',
        gatewayFeeUsd: result.gatewayFeeUsd,
        gatewayRawResponse: result.rawResponse as any,
      },
    });

    if (payment.installmentId) {
      await this.prisma.installment.update({
        where: { id: payment.installmentId },
        data: { status: result.success ? 'paid' : 'failed', paidAt: result.success ? new Date() : undefined },
      });
    }

    // إن كانت الدفعة مرتبطة بدورة (وليس طلبًا خاصًا)، تُنشأ حصة المدرب تلقائيًا
    if (result.success && payment.relatedType === 'course_enrollment') {
      await this.createInstructorEarning(payment.id, result.gatewayFeeUsd);
    }
  }

  /**
   * يترجم معادلة الاحتساب المتفق عليها بدقة:
   * gross → خصم عمولة البوابة أولًا → تقسيم الصافي بين المدرب والمنصة حسب النسبة الفعّالة.
   */
  private async createInstructorEarning(paymentId: string, gatewayFeeUsd: number) {
    const payment = await this.prisma.payment.findUniqueOrThrow({ where: { id: paymentId } });

    const course = await this.prisma.course.findUnique({ where: { id: payment.relatedId } });
    if (!course) return;

    const netAfterGateway = Number(payment.amountUsd) - gatewayFeeUsd;
    const commissionPercent = await this.resolveCommissionPercent(course.instructorId, course.id, course.level);

    const instructorEarningUsd = netAfterGateway * (commissionPercent / 100);
    const platformFeeUsd = netAfterGateway - instructorEarningUsd;

    const clearanceDate = new Date();
    clearanceDate.setDate(clearanceDate.getDate() + REFUND_WINDOW_DAYS);

    await this.prisma.instructorEarning.create({
      data: {
        instructorId: course.instructorId,
        paymentId: payment.id,
        courseId: course.id,
        grossAmountUsd: payment.amountUsd,
        gatewayFeeUsd,
        netAfterGatewayUsd: netAfterGateway,
        commissionPercentApplied: commissionPercent,
        instructorEarningUsd,
        platformFeeUsd,
        status: 'pending_clearance',
        clearanceDate,
      },
    });
  }

  /**
   * أولوية تحديد النسبة كما اتُّفق عليه:
   * 1. اتفاقية خاصة بالمدرب + الدورة   2. اتفاقية عامة للمدرب   3. السياسة الافتراضية لمستوى الدورة
   */
  private async resolveCommissionPercent(
    instructorId: string,
    courseId: string,
    courseLevel: string,
  ): Promise<number> {
    const specificAgreement = await this.prisma.instructorCommissionAgreement.findFirst({
      where: { instructorId, courseId, status: 'active' },
    });
    if (specificAgreement) return Number(specificAgreement.instructorSharePercent);

    const generalAgreement = await this.prisma.instructorCommissionAgreement.findFirst({
      where: { instructorId, courseId: null, status: 'active' },
    });
    if (generalAgreement) return Number(generalAgreement.instructorSharePercent);

    const defaultPolicy = await this.prisma.commissionPolicy.findFirst({
      where: { courseLevel: courseLevel as any, effectiveTo: null },
      orderBy: { effectiveFrom: 'desc' },
    });
    if (!defaultPolicy) {
      throw new BadRequestException('لا توجد سياسة عمولة مُعرَّفة لهذا المستوى من الدورات');
    }
    return Number(defaultPolicy.instructorSharePercent);
  }
}
