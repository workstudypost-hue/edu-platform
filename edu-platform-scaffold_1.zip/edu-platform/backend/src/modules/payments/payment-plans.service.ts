import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ExchangeRateService } from './exchange-rate.service';
import { CreatePaymentPlanDto } from './dto/create-payment-plan.dto';
import { InstallmentManagement } from '@prisma/client';

const REFUND_WINDOW_DAYS = 14; // فترة احتجاز أرباح المدرب (كما اتُّفق عليه)
const GRACE_PERIOD_DAYS = 7;   // مهلة السماح عند التعثر (كما اتُّفق عليه - القرار المعتمد)

@Injectable()
export class PaymentPlansService {
  constructor(
    private prisma: PrismaService,
    private exchangeRateService: ExchangeRateService,
  ) {}

  /**
   * ينشئ خطة دفع بالتقسيط الداخلي (خصم من بطاقة محفوظة عبر Stripe).
   * لخطط BNPL (Tabby/Tamara) يُستخدم installmentManagement='gateway_managed'
   * والبوابة نفسها تدير الجدولة - هذه الدالة توثّق فقط للعرض في هذه الحالة.
   *
   * القاعدة الأهم: سعر الصرف يُجمَّد هنا لحظة الإنشاء ولا يتغيّر طوال عمر الخطة.
   */
  async createPlan(dto: CreatePaymentPlanDto, studentId: string) {
    const lockedRate = await this.exchangeRateService.getCurrentRate(dto.billingCurrency);
    const billingAmountTotal = dto.totalAmountUsd * lockedRate;
    const installmentAmount = billingAmountTotal / dto.installmentsCount;

    const plan = await this.prisma.paymentPlan.create({
      data: {
        studentId,
        relatedType: dto.relatedType,
        relatedId: dto.relatedId,
        totalAmountUsd: dto.totalAmountUsd,
        billingCurrency: dto.billingCurrency,
        lockedExchangeRate: lockedRate,
        billingAmountTotal,
        installmentsCount: dto.installmentsCount,
        installmentManagement: InstallmentManagement.internal,
        status: 'active',
      },
    });

    // توليد الأقساط الشهرية (تاريخ استحقاق كل قسط = اليوم نفسه من الشهر التالي)
    const installmentsData = Array.from({ length: dto.installmentsCount }, (_, i) => {
      const dueDate = new Date();
      dueDate.setMonth(dueDate.getMonth() + i + 1);
      return {
        paymentPlanId: plan.id,
        installmentNumber: i + 1,
        amountBillingCurrency: installmentAmount,
        dueDate,
        status: 'upcoming' as const,
      };
    });

    await this.prisma.installment.createMany({ data: installmentsData });

    return this.prisma.paymentPlan.findUnique({
      where: { id: plan.id },
      include: { installments: { orderBy: { installmentNumber: 'asc' } } },
    });
  }

  /**
   * منطق Cron التحصيل اليومي (يُستدعى من BullMQ Job مجدول - راجع payments.module.ts).
   * يُطبَّق فقط على installmentManagement='internal' (BNPL تدير نفسها).
   */
  async processDueInstallments() {
    const today = new Date();
    const dueInstallments = await this.prisma.installment.findMany({
      where: {
        status: { in: ['upcoming', 'due'] },
        dueDate: { lte: today },
        paymentPlan: { installmentManagement: 'internal', status: 'active' },
      },
      include: { paymentPlan: true },
    });

    for (const installment of dueInstallments) {
      // TODO(production): استدعاء StripeAdapter.capturePayment باستخدام
      // saved_payment_methods الافتراضية للطالب، ثم تحديث الحالة حسب النتيجة.
      // عند الفشل المتكرر بعد GRACE_PERIOD_DAYS: تحديث enrollment.access_status='restricted'
      console.log(`[Cron:DEV_ONLY] معالجة القسط ${installment.id} المستحق`);
    }
  }
}
