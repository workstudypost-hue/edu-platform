import { Controller, Headers, Param, Post, Req } from '@nestjs/common';
import { Request } from 'express';
import { PaymentsService } from './payments.service';
import { PaymentGatewayFactory } from './adapters/payment-gateway.factory';
import { GatewayProvider } from '@prisma/client';

/**
 * نقاط الـ Webhook لكل بوابة - بدون JwtAuthGuard عمدًا (البوابة الخارجية هي المُستدعي).
 * التحقق من صحة المصدر يتم عبر توقيع البوابة نفسها (signature) داخل كل Adapter،
 * وليس عبر JWT للمستخدم.
 *
 * TODO(production): main.ts يحتاج تفعيل express.raw() لهذا المسار تحديدًا
 * (Stripe يتطلب الـ body الخام غير المُحلَّل للتحقق من التوقيع بدقة):
 *   app.use('/api/v1/webhooks/payments/stripe', express.raw({ type: 'application/json' }));
 */
@Controller('webhooks/payments')
export class WebhooksController {
  constructor(
    private paymentsService: PaymentsService,
    private gatewayFactory: PaymentGatewayFactory,
  ) {}

  @Post(':provider')
  async handleWebhook(
    @Param('provider') provider: GatewayProvider,
    @Req() req: Request,
    @Headers('stripe-signature') stripeSignature: string,
  ) {
    const adapter = this.gatewayFactory.getAdapter(provider);
    const event = await adapter.handleWebhook(req.body, stripeSignature);

    if (event.eventType === 'payment_succeeded') {
      await this.paymentsService.confirmPaymentSuccess(event.gatewayTransactionId, provider);
    }
    // TODO(production): معالجة payment_failed و refund_completed بنفس المنطق

    return { received: true };
  }
}
