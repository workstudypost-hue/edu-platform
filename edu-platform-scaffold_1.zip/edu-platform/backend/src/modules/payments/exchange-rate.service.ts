import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ExchangeRateService {
  constructor(private prisma: PrismaService) {}

  /** السعر الحالي لعملة مقابل USD - يُستخدم للعرض وتجميد سعر خطط الدفع الجديدة */
  async getCurrentRate(targetCurrency: string): Promise<number> {
    if (targetCurrency === 'USD') return 1;

    const cached = await this.prisma.currentExchangeRate.findUnique({
      where: { targetCurrency },
    });
    if (!cached) {
      throw new Error(`لا يوجد سعر صرف مُحدَّث لعملة ${targetCurrency} - تحقق من Cron التحديث`);
    }
    return Number(cached.rate);
  }

  /**
   * Cron يومي/كل 6-24 ساعة: يسحب أسعار الصرف من مزود خارجي
   * ويحفظ نسخة تاريخية كاملة (exchange_rates) + يُحدِّث الكاش السريع (current_exchange_rates).
   * TODO(production): استبدال المصفوفة الثابتة بالاستدعاء الفعلي لـ Open Exchange Rates API.
   */
  async refreshRatesFromProvider(): Promise<void> {
    const SUPPORTED_CURRENCIES = ['SAR', 'AED', 'KWD', 'EUR', 'PHP', 'EGP', 'JOD'];

    // TODO(production): fetch('https://openexchangerates.org/api/latest.json?app_id=...')
    const mockRates: Record<string, number> = {
      SAR: 3.75,
      AED: 3.6725,
      KWD: 0.307,
      EUR: 0.92,
      PHP: 58.5,
      EGP: 48.5,
      JOD: 0.709,
    };

    for (const currency of SUPPORTED_CURRENCIES) {
      const rate = mockRates[currency];
      await this.prisma.exchangeRate.create({
        data: { targetCurrency: currency, rate, source: 'openexchangerates' },
      });
      await this.prisma.currentExchangeRate.upsert({
        where: { targetCurrency: currency },
        update: { rate },
        create: { targetCurrency: currency, rate },
      });
    }
  }
}
