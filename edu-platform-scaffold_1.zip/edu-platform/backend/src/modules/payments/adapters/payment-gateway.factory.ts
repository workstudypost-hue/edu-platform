import { Injectable } from '@nestjs/common';
import { GatewayProvider } from '@prisma/client';
import { PaymentGatewayAdapter } from './payment-gateway.adapter';
import { StripeAdapter } from './stripe.adapter';
import { TabbyAdapter } from './tabby.adapter';

@Injectable()
export class PaymentGatewayFactory {
  constructor(
    private stripeAdapter: StripeAdapter,
    private tabbyAdapter: TabbyAdapter,
    // TODO(production): حقن PayPalAdapter و TamaraAdapter عند تنفيذهما
  ) {}

  getAdapter(provider: GatewayProvider): PaymentGatewayAdapter {
    switch (provider) {
      case 'stripe':
        return this.stripeAdapter;
      case 'tabby':
        return this.tabbyAdapter;
      case 'paypal':
      case 'tamara':
        throw new Error(`Adapter لبوابة ${provider} لم يُنفَّذ بعد - راجع production-notes.md`);
      default:
        throw new Error(`بوابة دفع غير معروفة: ${provider}`);
    }
  }
}
