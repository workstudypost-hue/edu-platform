import { Injectable } from '@nestjs/common';
import {
  PaymentGatewayAdapter,
  CreatePaymentIntentParams,
  GatewaySession,
  PaymentResult,
  RefundResult,
  WebhookEvent,
} from './payment-gateway.adapter';

/**
 * تطبيق Tabby (BNPL - السعودية/الإمارات/الكويت).
 * الفرق الجوهري عن Stripe: Tabby تُحوِّل للمنصة كامل المبلغ فورًا،
 * وهي من تُحصِّل الأقساط من الطالب مباشرة وتتحمّل مخاطر التعثر.
 * لذلك supportsGatewayManagedInstallments() = true، ولا Cron تحصيل داخلي لهذه الحالة.
 *
 * TODO(production): استبدال هذا التنفيذ بالاستدعاء الفعلي لـ Tabby Checkout API
 * (https://docs.tabby.ai) - البنية جاهزة، فقط تفاصيل الـ HTTP calls مطلوبة.
 */
@Injectable()
export class TabbyAdapter implements PaymentGatewayAdapter {
  readonly providerName = 'tabby' as const;

  async createPaymentIntent(params: CreatePaymentIntentParams): Promise<GatewaySession> {
    // TODO(production): POST /api/v2/checkout عبر Tabby SDK/HTTP
    throw new Error('Tabby adapter: يتطلب تفعيل مفاتيح API الفعلية - راجع production-notes.md');
  }

  async capturePayment(sessionId: string): Promise<PaymentResult> {
    throw new Error('غير منفَّذ - Stub لطبقة التصميم فقط');
  }

  async refund(gatewayTransactionId: string, amountUsd: number): Promise<RefundResult> {
    throw new Error('غير منفَّذ - Stub لطبقة التصميم فقط');
  }

  async handleWebhook(payload: unknown, signature: string): Promise<WebhookEvent> {
    throw new Error('غير منفَّذ - Stub لطبقة التصميم فقط');
  }

  supportsGatewayManagedInstallments(): boolean {
    return true;
  }

  supportedCurrencies(): string[] {
    return ['SAR', 'AED', 'KWD'];
  }

  supportedCountries(): string[] {
    return ['SA', 'AE', 'KW'];
  }
}
