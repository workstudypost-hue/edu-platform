import { BadRequestException, ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../../prisma/prisma.service';
import { RbacService } from '../../rbac/rbac.service';
import { OtpService } from './otp.service';
import { RegisterDto } from '../dto/register.dto';
import { LoginDto } from '../dto/login.dto';
import { OtpChannel, OtpPurpose } from '@prisma/client';

@Injectable()
export class PublicAuthService {
  constructor(
    private prisma: PrismaService,
    private rbac: RbacService,
    private otpService: OtpService,
    private jwtService: JwtService,
  ) {}

  /**
   * الخطوة 1: بدء التسجيل الذاتي (طالب أو مدرب فقط - أبدًا موظف).
   * الحساب يُنشأ بحالة pending_verification ولا يُفعَّل حتى التحقق من OTP.
   */
  async register(dto: RegisterDto) {
    if (!dto.email && !dto.phone) {
      throw new BadRequestException('يجب إدخال بريد إلكتروني أو رقم هاتف');
    }
    if (dto.requestedRole !== 'student' && dto.requestedRole !== 'instructor') {
      // دفاع إضافي بعد الـ DTO validation - لا مسار تسجيل ذاتي لأي دور غير هذين
      throw new BadRequestException('الدور المطلوب غير متاح للتسجيل الذاتي');
    }

    const existing = await this.prisma.user.findFirst({
      where: { OR: [{ email: dto.email }, { phone: dto.phone }] },
    });
    if (existing) {
      throw new ConflictException('يوجد حساب مسجَّل مسبقًا بهذا البريد/الهاتف');
    }

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const user = await this.prisma.user.create({
      data: {
        email: dto.email,
        phone: dto.phone,
        passwordHash,
        registrationType: 'self_service',
        preferredLocale: dto.preferredLocale,
        status: 'pending_verification',
      },
    });

    // ربط الدور المطلوب فورًا (الصلاحيات الفعلية تُفعَّل بعد التحقق من OTP)
    const role = await this.prisma.role.findUniqueOrThrow({ where: { name: dto.requestedRole } });
    await this.prisma.userRole.create({ data: { userId: user.id, roleId: role.id } });

    // إن كان مدربًا: يُنشأ ملف تعريف بحالة "بانتظار الموافقة الإدارية" فورًا
    // (منفصل تمامًا عن تفعيل تسجيل الدخول نفسه - كما اتُّفق عليه)
    if (dto.requestedRole === 'instructor') {
      await this.prisma.instructorProfile.create({
        data: { userId: user.id, accountStatus: 'active_pending_approval' },
      });
    }

    const identifier = dto.email ?? dto.phone!;
    const channel: OtpChannel = dto.email ? 'email' : 'sms';
    await this.otpService.generateAndSend(identifier, channel, 'registration', user.id);

    return { userId: user.id, message: 'تم إرسال رمز التحقق', identifier };
  }

  /**
   * الخطوة 2: تأكيد OTP → تفعيل الحساب وإصدار الجلسة.
   */
  async verifyRegistrationOtp(identifier: string, code: string) {
    await this.otpService.verify(identifier, code, 'registration');

    const user = await this.prisma.user.findFirst({
      where: { OR: [{ email: identifier }, { phone: identifier }] },
    });
    if (!user) throw new BadRequestException('المستخدم غير موجود');

    const isEmail = identifier === user.email;
    await this.prisma.user.update({
      where: { id: user.id },
      data: {
        status: 'active',
        emailVerifiedAt: isEmail ? new Date() : undefined,
        phoneVerifiedAt: !isEmail ? new Date() : undefined,
      },
    });

    return this.issueTokens(user.id);
  }

  /**
   * تسجيل الدخول بكلمة المرور (طلاب/مدربون فقط - الموظفون لهم مسار منفصل).
   */
  async login(dto: LoginDto) {
    const user = await this.prisma.user.findFirst({
      where: { OR: [{ email: dto.identifier }, { phone: dto.identifier }], isStaff: false },
    });
    if (!user || !user.passwordHash) {
      throw new UnauthorizedException('بيانات الدخول غير صحيحة');
    }
    const passwordValid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!passwordValid) {
      throw new UnauthorizedException('بيانات الدخول غير صحيحة');
    }
    if (user.status !== 'active') {
      throw new UnauthorizedException('الحساب غير مُفعَّل بعد - يُرجى إكمال التحقق');
    }

    return this.issueTokens(user.id);
  }

  /**
   * إصدار Access + Refresh Tokens مع تضمين الأدوار في الـ payload
   * (يُستخدم لاحقًا فورًا في PermissionsGuard دون استعلام إضافي على كل Request).
   */
  private async issueTokens(userId: string) {
    const roles = await this.rbac.getUserRoleNames(userId);
    const payload = { sub: userId, roles };

    const accessToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_ACCESS_SECRET,
      expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m',
    });
    const refreshToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_REFRESH_SECRET,
      expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '7d',
    });

    return { accessToken, refreshToken };
  }
}
