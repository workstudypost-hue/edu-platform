import { Body, Controller, Post } from '@nestjs/common';
import { PublicAuthService } from './public-auth.service';
import { RegisterDto } from '../dto/register.dto';
import { VerifyOtpDto } from '../dto/verify-otp.dto';
import { LoginDto } from '../dto/login.dto';

/**
 * مسارات المصادقة العامة (طلاب/مدربون - تسجيل ذاتي).
 * لا يوجد هنا أي مسار لإنشاء حساب "موظف" - هذا مفصول بالكامل
 * في StaffAuthController تحت /auth/staff فقط.
 */
@Controller('auth/public')
export class PublicAuthController {
  constructor(private readonly publicAuthService: PublicAuthService) {}

  @Post('register')
  register(@Body() dto: RegisterDto) {
    return this.publicAuthService.register(dto);
  }

  @Post('verify-otp')
  verifyOtp(@Body() dto: VerifyOtpDto) {
    return this.publicAuthService.verifyRegistrationOtp(dto.identifier, dto.code);
  }

  @Post('login')
  login(@Body() dto: LoginDto) {
    return this.publicAuthService.login(dto);
  }

  // TODO: /google و /microsoft callbacks تُضاف عبر Passport Strategies
  // (google-oauth.strategy.ts / microsoft-oauth.strategy.ts) - راجع production-notes.md
}
