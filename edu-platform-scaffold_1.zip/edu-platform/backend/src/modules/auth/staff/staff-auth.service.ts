import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { nanoid } from 'nanoid';
import { PrismaService } from '../../prisma/prisma.service';
import { RbacService } from '../../rbac/rbac.service';
import { CreateStaffInvitationDto } from '../dto/create-staff-invitation.dto';
import { AcceptStaffInvitationDto } from '../dto/accept-staff-invitation.dto';
import { LoginDto } from '../dto/login.dto';

const INVITATION_EXPIRY_HOURS = 48;

@Injectable()
export class StaffAuthService {
  constructor(
    private prisma: PrismaService,
    private rbac: RbacService,
    private jwtService: JwtService,
  ) {}

  /**
   * ينشئها super_admin حصريًا (يُطبَّق عبر PermissionsGuard على الـ Controller).
   * لا يوجد مسار عام لإنشاء حساب موظف بأي طريقة أخرى.
   */
  async createInvitation(dto: CreateStaffInvitationDto, invitedById: string) {
    const existingUser = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existingUser) {
      throw new BadRequestException('يوجد مستخدم مسجَّل مسبقًا بهذا البريد');
    }

    // إبطال أي دعوة سابقة سارية لنفس البريد (Token يُستهلك مرة واحدة فقط)
    await this.prisma.staffInvitation.updateMany({
      where: { email: dto.email, status: 'pending' },
      data: { status: 'revoked' },
    });

    const token = nanoid(32);
    const invitation = await this.prisma.staffInvitation.create({
      data: {
        email: dto.email,
        invitedRoleId: dto.roleId,
        invitedById,
        token,
        expiresAt: new Date(Date.now() + INVITATION_EXPIRY_HOURS * 60 * 60 * 1000),
      },
    });

    // TODO(production): إرسال بريد فعلي يحتوي رابط:
    // {FRONTEND_URL}/staff/accept-invitation?token={token}
    console.log(`[INVITATION:DEV_ONLY] رابط دعوة الموظف: token=${token}`);

    return { invitationId: invitation.id, expiresAt: invitation.expiresAt };
  }

  /**
   * الموظف يفتح الرابط ويُكمل إعداد حسابه (تعيين كلمة مرور).
   */
  async acceptInvitation(dto: AcceptStaffInvitationDto) {
    const invitation = await this.prisma.staffInvitation.findUnique({
      where: { token: dto.token },
    });

    if (!invitation || invitation.status !== 'pending') {
      throw new BadRequestException('رابط الدعوة غير صالح أو مُستخدَم مسبقًا');
    }
    if (invitation.expiresAt < new Date()) {
      await this.prisma.staffInvitation.update({
        where: { id: invitation.id },
        data: { status: 'expired' },
      });
      throw new BadRequestException('انتهت صلاحية رابط الدعوة');
    }

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const user = await this.prisma.$transaction(async (tx) => {
      const newUser = await tx.user.create({
        data: {
          email: invitation.email,
          passwordHash,
          isStaff: true,
          registrationType: 'staff_invitation',
          preferredLocale: 'ar',
          status: 'active',
          emailVerifiedAt: new Date(), // بريد موظف موثوق ضمنيًا عبر قناة الدعوة الإدارية
        },
      });

      await tx.userRole.create({
        data: { userId: newUser.id, roleId: invitation.invitedRoleId, assignedBy: invitation.invitedById },
      });

      await tx.staffInvitation.update({
        where: { id: invitation.id },
        data: { status: 'accepted' },
      });

      await tx.activityLog.create({
        data: {
          actorId: newUser.id,
          actorRole: 'staff',
          action: 'staff.account_activated',
          resourceType: 'user',
          resourceId: newUser.id,
        },
      });

      return newUser;
    });

    return this.issueTokens(user.id);
  }

  /**
   * تسجيل دخول منفصل تمامًا للموظفين (isStaff: true فقط).
   */
  async login(dto: LoginDto) {
    const user = await this.prisma.user.findFirst({
      where: { email: dto.identifier, isStaff: true },
    });
    if (!user || !user.passwordHash) {
      throw new UnauthorizedException('بيانات الدخول غير صحيحة');
    }
    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) {
      throw new UnauthorizedException('بيانات الدخول غير صحيحة');
    }
    if (user.status !== 'active') {
      throw new UnauthorizedException('الحساب غير نشط');
    }

    await this.prisma.activityLog.create({
      data: {
        actorId: user.id,
        actorRole: 'staff',
        action: 'staff.login',
        resourceType: 'user',
        resourceId: user.id,
      },
    });

    return this.issueTokens(user.id);
  }

  private async issueTokens(userId: string) {
    const roles = await this.rbac.getUserRoleNames(userId);
    const payload = { sub: userId, roles, isStaff: true };

    const accessToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_ACCESS_SECRET,
      expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m',
    });
    const refreshToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_REFRESH_SECRET,
      expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '7d',
    });

    return { accessToken, refreshToken };
  }
}
