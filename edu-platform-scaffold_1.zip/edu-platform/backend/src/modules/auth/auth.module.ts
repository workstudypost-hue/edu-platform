import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { PublicAuthController } from './public/public-auth.controller';
import { PublicAuthService } from './public/public-auth.service';
import { OtpService } from './public/otp.service';
import { StaffAuthController } from './staff/staff-auth.controller';
import { StaffAuthService } from './staff/staff-auth.service';
import { JwtStrategy } from './strategies/jwt.strategy';

@Module({
  imports: [
    PassportModule,
    JwtModule.register({}), // الأسرار تُمرَّر لكل توقيع/تحقق على حدة (Access مقابل Refresh)
  ],
  controllers: [PublicAuthController, StaffAuthController],
  providers: [PublicAuthService, StaffAuthService, OtpService, JwtStrategy],
  exports: [PublicAuthService, StaffAuthService],
})
export class AuthModule {}
