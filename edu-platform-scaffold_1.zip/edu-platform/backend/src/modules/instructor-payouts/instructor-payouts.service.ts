import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class InstructorPayoutsService {
  constructor(private prisma: PrismaService) {}

  /**
   * Cron دوري (حسب payout_frequency لكل مدرب): يجمّع كل الأرباح المُحرَّرة
   * (status='cleared', payoutId=null) وينشئ payout واحدًا، محددًا هل يتطلب
   * موافقة مزدوجة بناءً على dual_approval_thresholds (500$ افتراضيًا).
   */
  async generatePayoutForInstructor(instructorId: string, periodStart: Date, periodEnd: Date) {
    const clearedEarnings = await this.prisma.instructorEarning.findMany({
      where: { instructorId, status: 'cleared', payoutId: null },
    });
    if (clearedEarnings.length === 0) return null;

    const grossAmount = clearedEarnings.reduce((sum, e) => sum + Number(e.instructorEarningUsd), 0);

    const pendingDeductions = await this.prisma.instructorDeduction.findMany({
      where: { instructorId, status: 'pending' },
    });
    const deductionsTotal = pendingDeductions.reduce((sum, d) => sum + Number(d.amountUsd), 0);
    const netAmountUsd = grossAmount - deductionsTotal;

    const profile = await this.prisma.instructorProfile.findUnique({ where: { userId: instructorId } });
    const threshold = Number(profile?.minimumPayoutThreshold ?? 50);
    if (netAmountUsd < threshold) {
      // لا يُنشأ payout - يتراكم تلقائيًا للدورة القادمة (الأرباح تبقى بلا payoutId)
      return null;
    }

    const dualApprovalRule = await this.prisma.dualApprovalThreshold.findFirst({
      where: { isActive: true },
      orderBy: { minAmountUsd: 'asc' },
    });
    const requiresDualApproval = dualApprovalRule
      ? netAmountUsd >= Number(dualApprovalRule.minAmountUsd)
      : false;

    const payout = await this.prisma.$transaction(async (tx) => {
      const created = await tx.instructorPayout.create({
        data: {
          instructorId,
          periodStart,
          periodEnd,
          grossAmount,
          netAmountUsd,
          requiresDualApproval,
          status: 'calculated',
        },
      });

      await tx.instructorEarning.updateMany({
        where: { id: { in: clearedEarnings.map((e) => e.id) } },
        data: { payoutId: created.id },
      });

      await tx.instructorDeduction.updateMany({
        where: { id: { in: pendingDeductions.map((d) => d.id) } },
        data: { status: 'deducted', appliedToPayoutId: created.id },
      });

      return created;
    });

    return payout;
  }

  /**
   * الموافقة الأولى (finance_manager). إن لم تكن الدفعة تتطلب موافقة مزدوجة،
   * هذه الموافقة الوحيدة كافية → approved مباشرة.
   */
  async firstApproval(payoutId: string, approverId: string) {
    const payout = await this.prisma.instructorPayout.findUniqueOrThrow({ where: { id: payoutId } });

    if (payout.status !== 'calculated') {
      throw new BadRequestException('هذه الدفعة ليست بانتظار الموافقة الأولى');
    }

    const nextStatus = payout.requiresDualApproval ? 'pending_second_approval' : 'approved';

    return this.prisma.instructorPayout.update({
      where: { id: payoutId },
      data: {
        firstApprovalById: approverId,
        firstApprovalAt: new Date(),
        status: nextStatus,
      },
    });
  }

  /**
   * الموافقة الثانية (super_admin) - إلزامية فقط عند requiresDualApproval=true.
   * قيد صارم: يُمنع أن يكون المُوافِق الثاني نفس المُوافِق الأول.
   */
  async secondApproval(payoutId: string, approverId: string) {
    const payout = await this.prisma.instructorPayout.findUniqueOrThrow({ where: { id: payoutId } });

    if (payout.status !== 'pending_second_approval') {
      throw new BadRequestException('هذه الدفعة ليست بانتظار الموافقة الثانية');
    }
    if (payout.firstApprovalById === approverId) {
      throw new ForbiddenException(
        'لا يمكن لنفس الشخص أن يُصادق على الموافقتين الأولى والثانية لنفس الدفعة',
      );
    }

    return this.prisma.instructorPayout.update({
      where: { id: payoutId },
      data: {
        secondApprovalById: approverId,
        secondApprovalAt: new Date(),
        status: 'approved',
      },
    });
  }

  async reject(payoutId: string, reason: string) {
    return this.prisma.instructorPayout.update({
      where: { id: payoutId },
      data: { status: 'rejected', rejectionReason: reason },
    });
  }

  /**
   * ينفَّذ بعد status='approved' فقط. التنفيذ الفعلي (Stripe Connect/PayPal Payouts/
   * تحويل بنكي يدوي) يعتمد على instructor_profiles.preferred_payout_method.
   * TODO(production): استدعاء الـ API الفعلي حسب الطريقة.
   */
  async executePayout(payoutId: string) {
    const payout = await this.prisma.instructorPayout.findUniqueOrThrow({ where: { id: payoutId } });
    if (payout.status !== 'approved') {
      throw new BadRequestException('لا يمكن تنفيذ دفعة لم تُعتمَد بعد');
    }

    // TODO(production): استدعاء Stripe Connect Transfer / PayPal Payouts API هنا
    console.log(`[Payout:DEV_ONLY] تنفيذ تحويل ${payout.netAmountUsd}$ للمدرب ${payout.instructorId}`);

    return this.prisma.instructorPayout.update({
      where: { id: payoutId },
      data: { status: 'paid', paidAt: new Date() },
    });
  }
}
