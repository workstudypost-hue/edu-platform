import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Prisma Service مركزي — يُحقن في أي Service يحتاج الوصول لقاعدة البيانات.
 * لاحقًا: يمكن توسيعه لدعم Read Replica منفصلة لخدمة التقارير
 * (كما صُمم في نظام التقارير: Production DB مقابل Reporting Replica)
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}
