import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './modules/prisma/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { RbacModule } from './modules/rbac/rbac.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { InstructorPayoutsModule } from './modules/instructor-payouts/instructor-payouts.module';

@Module({
  imports: [
    // إعدادات البيئة متاحة عالميًا في كل الموديولات
    ConfigModule.forRoot({ isGlobal: true }),

    // حماية عامة من هجمات القوة الغاشمة (Brute-force) على مستوى كل الـ API
    ThrottlerModule.forRoot([
      {
        ttl: 60000, // نافذة 60 ثانية
        limit: 100, // 100 طلب لكل IP كحد افتراضي (يُخصَّص لاحقًا لكل Endpoint حساس مثل OTP)
      },
    ]),

    PrismaModule,
    RbacModule,
    UsersModule,
    AuthModule,
    PaymentsModule,
    InstructorPayoutsModule,
  ],
})
export class AppModule {}
