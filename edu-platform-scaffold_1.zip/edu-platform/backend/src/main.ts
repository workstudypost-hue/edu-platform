import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // أمان أساسي على مستوى الـ HTTP headers
  app.use(helmet());

  // تفعيل CORS محصور بنطاق الـ Frontend فقط
  app.enableCors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
  });

  // بادئة موحّدة لكل الـ API (كما صُمم في وثائق الـ Endpoints)
  app.setGlobalPrefix('api/v1');

  // التحقق التلقائي من كل DTO الوارد + رفض أي حقول غير معرّفة
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const port = process.env.PORT || 4000;
  await app.listen(port);
  console.log(`🚀 Backend running on http://localhost:${port}/api/v1`);
}
bootstrap();
