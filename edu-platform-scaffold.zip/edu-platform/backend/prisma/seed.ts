import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

// مصفوفة الصلاحيات كما اتُّفق عليها عبر جلسة التصميم الكاملة
const PERMISSIONS: Array<{ resource: string; action: string }> = [
  { resource: 'users', action: 'manage_staff' },
  { resource: 'users', action: 'read' },
  { resource: 'courses', action: 'create' },
  { resource: 'courses', action: 'edit' },
  { resource: 'courses', action: 'publish' },
  { resource: 'custom_requests', action: 'review' },
  { resource: 'custom_requests', action: 'price' },
  { resource: 'custom_requests', action: 'assign' },
  { resource: 'custom_requests', action: 'approve_final' },
  { resource: 'custom_requests', action: 'create' },
  { resource: 'payments', action: 'read' },
  { resource: 'payments', action: 'export' },
  { resource: 'refunds', action: 'approve' },
  { resource: 'instructor_payouts', action: 'read' },
  { resource: 'instructor_payouts', action: 'approve' },
  { resource: 'marketing_campaigns', action: 'manage' },
  { resource: 'activity_logs', action: 'read' },
];

const ROLES: Array<{ name: string; isSystemRole: boolean; permissions: string[] }> = [
  {
    name: 'super_admin',
    isSystemRole: true,
    permissions: PERMISSIONS.map((p) => `${p.resource}.${p.action}`), // كل الصلاحيات
  },
  {
    name: 'content_admin',
    isSystemRole: true,
    permissions: ['courses.create', 'courses.edit', 'courses.publish'],
  },
  {
    name: 'requests_reviewer',
    isSystemRole: true,
    permissions: ['custom_requests.review', 'custom_requests.price', 'custom_requests.assign'],
  },
  {
    name: 'finance_manager',
    isSystemRole: true,
    permissions: [
      'payments.read',
      'payments.export',
      'refunds.approve',
      'instructor_payouts.read',
      'instructor_payouts.approve',
    ],
  },
  {
    name: 'marketing_manager',
    isSystemRole: true,
    permissions: ['marketing_campaigns.manage'],
  },
  {
    name: 'support_agent',
    isSystemRole: true,
    permissions: ['users.read', 'activity_logs.read'],
  },
  {
    name: 'student',
    isSystemRole: true,
    permissions: ['custom_requests.create'],
  },
  {
    name: 'instructor',
    isSystemRole: true,
    permissions: [],
  },
];

async function main() {
  console.log('🌱 بدء تهيئة البيانات الأساسية...');

  // 1) إنشاء الصلاحيات
  for (const perm of PERMISSIONS) {
    await prisma.permission.upsert({
      where: { resource_action: { resource: perm.resource, action: perm.action } },
      update: {},
      create: perm,
    });
  }

  // 2) إنشاء الأدوار وربطها بالصلاحيات
  for (const roleDef of ROLES) {
    const role = await prisma.role.upsert({
      where: { name: roleDef.name },
      update: {},
      create: { name: roleDef.name, isSystemRole: roleDef.isSystemRole },
    });

    for (const permKey of roleDef.permissions) {
      const [resource, action] = permKey.split('.');
      const permission = await prisma.permission.findUniqueOrThrow({
        where: { resource_action: { resource, action } },
      });
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: role.id, permissionId: permission.id } },
        update: {},
        create: { roleId: role.id, permissionId: permission.id },
      });
    }
    console.log(`  ✓ دور "${roleDef.name}" جاهز بـ ${roleDef.permissions.length} صلاحية`);
  }

  // 3) إنشاء أول super_admin للدخول الأولي للنظام
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? 'admin@platform.local';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? 'ChangeMe123!';

  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    const adminUser = await prisma.user.create({
      data: {
        email: adminEmail,
        passwordHash,
        isStaff: true,
        registrationType: 'staff_invitation',
        preferredLocale: 'ar',
        status: 'active',
        emailVerifiedAt: new Date(),
      },
    });
    const superAdminRole = await prisma.role.findUniqueOrThrow({ where: { name: 'super_admin' } });
    await prisma.userRole.create({ data: { userId: adminUser.id, roleId: superAdminRole.id } });
    console.log(`  ✓ تم إنشاء super_admin: ${adminEmail} / ${adminPassword}`);
    console.log('  ⚠️  غيّر كلمة المرور فورًا بعد أول دخول');
  } else {
    console.log('  ℹ️  super_admin موجود مسبقًا، تم التخطي');
  }

  console.log('✅ اكتملت التهيئة');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
